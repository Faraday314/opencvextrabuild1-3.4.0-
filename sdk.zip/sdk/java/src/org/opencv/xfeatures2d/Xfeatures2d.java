//
// This file is auto-generated. Please don't modify it!
//
package org.opencv.xfeatures2d;



// C++: class Xfeatures2d
//javadoc: Xfeatures2d

public class Xfeatures2d {



}
